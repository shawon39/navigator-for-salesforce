// commandPalette.js
// Option/Alt+K command palette for fast Salesforce navigation.
// Grouped fuzzy search over setup pages, objects, setup tabs, bookmarks, recents, and
// (when live org access is enabled) the org's objects + records via the
// background worker's authenticated API calls.
// Static data, icons, and pure helpers live in commandPalette.data.js (loaded
// first via the manifest) and are read from window.SFEN_CMDK_DATA below.
(function () {
    "use strict";

    // The manifest's matches already limit this script to Salesforce hosts.
    if (!extAlive()) return;
    const host = window.location.hostname;

    const {
        PALETTE_CSS,
        GROUPS,
        VERBS,
        VERB_SHORT,
        COMMANDS,
        sortLimits,
        SETUP_PAGES,
        FALLBACK_OBJECTS,
        isRelevantObject,
        objectEntries,
        objectActions,
        objectScore,
        objectVerbEntries,
        PACKAGE_PENALTY,
        packageQuery,
        pickBonus,
        addPick,
        iconSvg,
        ICON_TONES,
        UI_ICONS,
        looksLikeRecordId,
        pastedLink,
        highlightPositions,
        escapeHtml,
        lightningOrigin,
        navigate,
        recordUrl,
    } = window.SFEN_CMDK_DATA;
    const SETUP_ALIASES = window.SFEN_SETUP_ALIASES || {};

    const DEFAULT_PLACEHOLDER = "Search Setup, objects, records and bookmarks";

    // ---- State -----------------------------------------------------------
    let staticCatalog = [];
    let liveObjects = null; // [{api,label,plural}] once fetched
    let liveRecords = []; // current async search results
    let recents = []; // persisted recently-chosen palette items
    let recentRecords = []; // org "recently viewed" records
    let liveEnabled = true;
    let paletteEnabled = true; // settings.commandPalette
    let objectsRequested = false;
    let adminItems = []; // profiles, permission sets, flows, Apex, metadata types, newest first
    let adminRequested = false;
    let adminLoaded = false; // adminItems arrived at least once (they can be empty)
    let adminFailed = false; // the last ask failed; the next open asks again
    let adminAskedAt = 0; // when adminItems were last asked for; an open refetches them after ADMIN_MAX_AGE
    const ADMIN_MAX_AGE = 10 * 60 * 1000;
    let appItems = null; // the user's Lightning apps, in App Launcher order, once fetched
    let appsRequested = false;
    let fieldsCache = {}; // object API name -> [{api,label,type,key}] for the "fields" verb
    let fieldsFailed = {}; // object API names whose fields failed to load (retried on the next open)
    let fieldsKey = null; // object whose fields are being fetched; a response for another is ignored
    let listViewsCache = {}; // object API name -> [{id,label,api}] or "failed", for the "list" verb
    let listViewsKey = null; // object whose list views are being fetched
    let listRecentCache = {}; // object API name -> your last 5 viewed [{id,name}], loaded with its list views
    let countCache = {}; // object API name -> { total, recordTypes } or "failed", for the "count" verb
    let countKey = null; // object whose records are being counted
    let limitsData = null; // [{name,max,remaining}] or "failed", for Org Limits; refetched per open
    let limitsLoading = false;
    let recentCache = {}; // object API name -> your last 20 viewed records, for the "recent" verb
    let recentCount = SFEN_SETTINGS.DEFAULTS.recentCount; // settings.recentCount: recently viewed records shown
    let showPackageApex = false; // settings.showPackageApex: the apex list includes managed-package code
    let recentKey = null; // object whose last viewed records are being fetched
    let activeUsers = null; // active users who logged in last, for "users" with nothing typed; refetched per open
    let activeUsersLoading = false;
    let catalogCache = null; // fullCatalog() result; reset when its sources change
    let currentQuery = ""; // last query passed to render()
    let expandedKey = null; // url of the row whose ⋯ actions are expanded
    let activeVerb = null; // active command verb key (VERBS), or null
    let shortcutsOpen = false; // the Shortcuts list shows in place of the board
    let autoVerbWord = null; // verb word as typed when "word " switched it on; null when locked
    let inspectKey = null; // "Type/Id" currently fetched for the record inspector
    let inspectRecord = null; // fetched record fields for the record inspector
    const describeCache = {}; // "host/Type" -> { fieldApiName: label } for the inspector
    let liveRecordsTerm = ""; // search term liveRecords were returned for
    let orgName = ""; // current org's saved or default name, shown in the search bar
    let orgKind = ""; // SFEN_ORGS.orgType of the current org (its type tag)
    let savedOrgs = []; // saved orgs (quickOrgs), listed by the "org" verb
    let currentOrg = null; // the saved org this page belongs to, if any
    let tabColors = false; // settings.orgTabColors: org color icons instead of type dots
    let orgColorMap = Object.create(null); // org key -> color name (SFEN_ORG_COLORS.assign)
    let paletteDark = false; // the palette's resolved theme, for icon shades
    let peekOpen = false; // the record preview beside the results is showing
    let peekTimer = null;
    let peekEntry = null; // the result row the preview shows
    const peekCache = {}; // record Id -> peek record, "loading" or "failed"
    let hop = null; // the current record's lookups ("hop" action)
    let hopKey = null; // record Id hop was requested for
    let hopAt = 0; // when hop was requested

    // Key hints: ⌘ on Mac, Ctrl elsewhere.
    const MOD = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent) ? "⌘" : "Ctrl+";

    function buildStaticCatalog(cb) {
        if (!extAlive()) return;
        chrome.storage.sync.get(
            { sfTabs: [], bookmarks: [] },
            (res) => {
                if (chrome.runtime.lastError || !res) return;
                const items = [];
                SETUP_PAGES.forEach(([label, url, category]) => {
                    let keywords = `${label} ${category || ""} setup`;
                    if (label === "Users") keywords += " manage users list";
                    items.push({ label, hint: "Setup", group: GROUPS.SETUP, url, keywords });
                });
                // Opens the Org Limits view in the palette, not a page (see choose).
                items.push({
                    label: "Org Limits",
                    hint: "Limits",
                    group: GROUPS.SETUP,
                    url: "/lightning/setup/SystemOverview/home",
                    keywords: "org limits usage api requests storage email",
                    openLimits: true,
                });
                (res.sfTabs || []).forEach((t) => {
                    if (t && t.name && SFEN_URL.isSafePath(t.link))
                        items.push({ label: t.name, hint: "Setup Tab", group: GROUPS.SETUP_TAB, url: t.link, keywords: `${t.name} setup tab` });
                });
                (res.bookmarks || []).forEach((b) => {
                    if (b && b.title && SFEN_URL.isSafePath(b.url))
                        items.push({ label: b.title, hint: "Bookmark", group: GROUPS.BOOKMARK, url: b.url, keywords: `${b.title} bookmark` });
                });
                staticCatalog = items;
                catalogCache = null;
                if (cb) cb();
            }
        );
    }

    function objectCatalog() {
        const items = [];
        const source =
            liveObjects && liveObjects.length
                ? liveObjects
                : FALLBACK_OBJECTS.map((n) => ({ api: n, label: n }));
        source.forEach((o) =>
            objectEntries(o.api, o.label).forEach((e) => items.push(e))
        );
        return items;
    }

    function fullCatalog() {
        if (!catalogCache) catalogCache = staticCatalog.concat(objectCatalog(), adminItems, appItems || []);
        return catalogCache;
    }

    // The empty-query state is the overview board (renderBoard); compute() only
    // handles the typed-search path.
    function compute(query) {
        const raw = query.trim();
        const q = raw.toLowerCase();
        const out = [];
        // Pasting a 15/18-char record Id jumps straight to that record. Its
        // preview names it once loaded; Ids of things that aren't records
        // (a profile, a class) keep the plain row.
        if (looksLikeRecordId(raw)) {
            const known = peekRecord(raw);
            out.push(
                known
                    ? { label: known.name, sub: `${known.typeLabel} · ${raw}`, hint: "ID", group: GROUPS.ACTION, url: recordUrl(known.type, raw), recordId: raw }
                    : { label: "Open record: " + raw, hint: "ID", group: GROUPS.ACTION, url: "/" + raw, recordId: raw }
            );
        }
        // A pasted link to an org's page opens that page in this org;
        // renderList explains the ones that can't.
        const link = pastedLink(raw, host);
        if (link) {
            if (link.path)
                out.push({ label: `Open this page in ${orgName || "this org"}`, sub: link.path, hint: "Link", group: GROUPS.ACTION, url: link.path });
            return out;
        }
        if (!q) return out;
        // Setup pages, setup tabs, and bookmarks are deliberate destinations, so
        // rank them above incidental object matches (e.g. "flows" -> Setup, not objects).
        const GROUP_BONUS = {
            [GROUPS.BOOKMARK]: 10,
            [GROUPS.SETUP_TAB]: 10,
            [GROUPS.SETUP]: 8,
            [GROUPS.APP]: 8,
            [GROUPS.OBJECT]: 0,
            [GROUPS.RECORD]: 0,
            [GROUPS.RELATED]: 9,
        };
        const alias = SETUP_ALIASES[q];
        const scored = [];
        for (const item of fullCatalog().concat(hopItems())) {
            const itemQuery = packageQuery(item, q);
            if (itemQuery === null) continue;
            // Admin shorthand ("psg") ranks just under an exact name. A lookup
            // of the record you're on also matches its field as a name, so
            // "acc" on an Opportunity finds its Account like a page named so.
            const sc =
                item.group === GROUPS.SETUP && item.label === alias
                    ? 950
                    : Math.max(SFEN_URL.matchScore(itemQuery, item.label, item.keywords), item.field ? SFEN_URL.matchScore(itemQuery, item.field) : -1);
            if (sc >= 0)
                scored.push({ item, sc: sc + (GROUP_BONUS[item.group] || 0) - (item.pkg ? PACKAGE_PENALTY : 0) + boost(item.url) });
        }
        liveRecords.forEach((item) => {
            const sc = SFEN_URL.matchScore(q, item.label, item.keywords);
            // Records came back from a server search for this term; always
            // include them, but only boost the ones that match the query.
            scored.push({ item, sc: sc >= 0 ? sc + 6 + boost(item.url) : 0 });
        });
        scored.sort((a, b) => b.sc - a.sc);

        // Cap noisy groups so a flood of object matches can't crowd out the rest.
        const caps = {
            [GROUPS.OBJECT]: 6,
            [GROUPS.SETUP]: 12,
            [GROUPS.RECORD]: 8,
            [GROUPS.SETUP_TAB]: 8,
            [GROUPS.BOOKMARK]: 8,
            [GROUPS.FLOW]: 6,
            [GROUPS.PROFILE]: 6,
            [GROUPS.PERMSET]: 6,
            [GROUPS.APP]: 6,
            [GROUPS.APEX]: 6,
            [GROUPS.CMDT]: 4,
            [GROUPS.RELATED]: 6,
        };
        const counts = {};
        for (const s of scored) {
            const g = s.item.group;
            counts[g] = (counts[g] || 0) + 1;
            if (caps[g] && counts[g] > caps[g]) continue;
            out.push(s.item);
            if (out.length >= 24) break;
        }
        return out;
    }

    // ---- Live org access -------------------------------------------------
    function ask(action, extra, cb) {
        if (!extAlive()) {
            cb(null);
            return;
        }
        try {
            chrome.runtime.sendMessage(
                { type: "palette", action, host, ...extra },
                (resp) => {
                    if (chrome.runtime.lastError || !resp || !resp.ok) {
                        cb(null);
                        return;
                    }
                    cb(resp);
                }
            );
        } catch (e) {
            cb(null);
        }
    }

    function loadObjects() {
        if (!liveEnabled || objectsRequested) return;
        objectsRequested = true;
        ask("objects", {}, (resp) => {
            if (!resp || !liveEnabled) {
                objectsRequested = false; // retry on the next open
                return;
            }
            liveObjects = resp.sobjects
                .filter(isRelevantObject)
                .map((s) => ({ api: s.name, label: s.label, plural: s.labelPlural, prefix: s.keyPrefix }));
            catalogCache = null;
            loadHop(); // a /lightning/r/{Id}/view page needs the objects to know its record
            if (opened) render(inputEl.value);
        });
    }

    // Profiles, permission sets, flows, Apex classes and triggers, and custom
    // metadata types — fetched once, fuzzy-searched like objects. Each carries
    // a hint so the result type is obvious.
    // The old list stays in use until the refetched one arrives.
    function loadAdmin() {
        if (Date.now() - adminAskedAt > ADMIN_MAX_AGE) adminRequested = false;
        if (!liveEnabled || adminRequested) return;
        adminRequested = true;
        adminFailed = false;
        adminAskedAt = Date.now();
        ask("admin", {}, (resp) => {
            if (!resp || !liveEnabled) {
                adminRequested = false;
                adminFailed = !!liveEnabled;
                if (opened && activeVerb && VERBS[activeVerb].kind === "admin") render(inputEl.value);
                return;
            }
            const profiles = (resp.profiles || []).map((p) => ({
                label: p.Name,
                hint: "Profile",
                group: GROUPS.PROFILE,
                url: `/lightning/setup/EnhancedProfiles/page?address=%2F${p.Id}`,
                keywords: `${p.Name || ""} profile`,
            }));
            const permSets = (resp.permissionSets || []).map((p) => ({
                label: p.Label || p.Name,
                hint: "Permission Set",
                group: GROUPS.PERMSET,
                url: `/lightning/setup/PermSets/page?address=%2F${p.Id}`,
                keywords: `${p.Label || ""} ${p.Name || ""} permission set permset`,
            }));
            const flows = (resp.flows || []).map((f) => ({
                label: f.Label || f.ApiName,
                hint: "Flow",
                group: GROUPS.FLOW,
                // Flow Builder opens a flow VERSION (301), not the definition (300).
                // Prefer the latest version (matches the Setup list's behavior),
                // then the active version, then fall back to the definition id.
                url: `/builder_platform_interaction/flowBuilder.app?flowId=${f.LatestVersionId || f.ActiveVersionId || f.DurableId}`,
                flow: f.DurableId, // lets Recent Setup follow newer versions
                keywords: `${f.Label || ""} ${f.ApiName || ""} flow ${f.ProcessType || ""}`,
            }));
            const apex = (resp.apexClasses || [])
                .map((c) => ({
                    label: c.Name,
                    hint: c.NamespacePrefix ? `Apex Class · ${c.NamespacePrefix}` : "Apex Class",
                    group: GROUPS.APEX,
                    pkg: c.NamespacePrefix || null, // hidden unless the query names the package
                    url: `/lightning/setup/ApexClasses/page?address=%2F${c.Id}`,
                    keywords: `${c.Name} ${c.NamespacePrefix || ""} apex class code`,
                }))
                .concat(
                    (resp.apexTriggers || []).map((t) => ({
                        label: t.Name,
                        hint: ["Apex Trigger", t.Object, t.NamespacePrefix].filter(Boolean).join(" · "),
                        group: GROUPS.APEX,
                        pkg: t.NamespacePrefix || null,
                        url: `/lightning/setup/ApexTriggers/page?address=%2F${t.Id}`,
                        keywords: `${t.Name} ${t.Object || ""} ${t.NamespacePrefix || ""} apex trigger code`,
                    }))
                );
            const metadataTypes = (resp.metadataTypes || []).map((m) => ({
                label: m.Label,
                api: m.Label !== m.ApiName ? m.ApiName : "",
                hint: "Custom Metadata Type",
                group: GROUPS.CMDT,
                url: `/lightning/setup/CustomMetadata/page?address=%2F${m.Id}%3Fsetupid%3DCustomMetadata`,
                keywords: `${m.Label} ${m.ApiName} custom metadata type cmdt`,
                actions: m.KeyPrefix
                    ? [{ label: "Manage records", hint: "Records", kind: "nav", url: `/lightning/setup/CustomMetadata/page?address=%2F${m.KeyPrefix}` }]
                    : null,
            }));
            adminItems = profiles.concat(permSets, flows, apex, metadataTypes);
            adminLoaded = true;
            catalogCache = null;
            if (opened && (inputEl.value.trim() || activeVerb)) render(inputEl.value);
        });
    }

    // The user's Lightning apps — fetched once, searched like admin items and
    // listed by the "app" verb.
    function loadApps() {
        if (!liveEnabled || appsRequested) return;
        appsRequested = true;
        ask("apps", {}, (resp) => {
            if (!resp || !liveEnabled) {
                appsRequested = false;
                if (opened && activeVerb) render(inputEl.value);
                return;
            }
            appItems = (resp.apps || []).map((a) => ({
                label: a.label,
                hint: a.console ? "Console app" : "App",
                group: GROUPS.APP,
                url: `/lightning/app/${a.id}`,
                keywords: `${a.label} app${a.console ? " console" : ""}`,
            }));
            catalogCache = null;
            if (opened && (activeVerb || inputEl.value.trim())) render(inputEl.value);
        });
    }

    // One object's fields for the "fields" verb, cached for the page's life.
    function loadFields(api) {
        if (fieldsCache[api] || fieldsFailed[api] || fieldsKey === api) return;
        fieldsKey = api;
        setLoading("fields", true);
        ask("fields", { object: api }, (resp) => {
            if (fieldsKey !== api) return; // stale: another object, or the verb was cleared
            fieldsKey = null;
            setLoading("fields", false);
            if (resp) fieldsCache[api] = resp.fields || [];
            else fieldsFailed[api] = true;
            if (opened && activeVerb === "fields") render(inputEl.value);
        });
    }

    // One object's list views for the "list" verb, cached for the page's life.
    function loadListViews(api) {
        if (listViewsCache[api] || listViewsKey === api) return;
        listViewsKey = api;
        setLoading("listViews", true);
        ask("listViews", { object: api }, (resp) => {
            if (listViewsKey !== api) return; // stale: another object, or the verb was cleared
            listViewsKey = null;
            setLoading("listViews", false);
            listViewsCache[api] = resp ? resp.listViews || [] : "failed";
            listRecentCache[api] = (resp && resp.records) || [];
            if (opened && activeVerb === "list") render(inputEl.value);
        });
    }

    // One object's record counts for the "count" verb, refetched per open.
    function loadCounts(api) {
        if (countCache[api] || countKey === api) return;
        countKey = api;
        setLoading("count", true);
        ask("count", { object: api }, (resp) => {
            if (countKey !== api) return; // stale: another object, or the verb was cleared
            countKey = null;
            setLoading("count", false);
            countCache[api] = resp || "failed";
            if (opened && activeVerb === "count") render(inputEl.value);
        });
    }

    // One object's last viewed records for the "recent" verb, refetched per open.
    function loadObjectRecent(api) {
        if (recentCache[api] || recentKey === api) return;
        recentKey = api;
        setLoading("recent", true);
        ask("recent", { object: api }, (resp) => {
            if (recentKey !== api) return; // stale: another object, or the verb was cleared
            recentKey = null;
            setLoading("recent", false);
            // Objects RecentlyViewed doesn't track fail; they show nothing, like no records.
            recentCache[api] = ((resp && resp.records) || []).map(mapRecord);
            if (opened && activeVerb === "recent") render(inputEl.value);
        });
    }

    // ---- Record -> palette item ------------------------------------------
    function userSub(r) {
        const parts = [];
        if (r.ProfileName) parts.push(r.ProfileName);
        if (r.IsActive === false) parts.push("Inactive");
        else if (r.IsActive === true) parts.push("Active");
        if (r.Username) parts.push("@" + r.Username);
        return parts.join(" · ");
    }

    function mapRecord(r) {
        const type = r.attributes ? r.attributes.type : "Record";
        const name = r.Name || r.CaseNumber || r.ContractNumber || r.OrderNumber || r.Id;
        const item = {
            label: name,
            hint: type,
            group: GROUPS.RECORD,
            url: recordUrl(type, r.Id),
            recordId: r.Id, // → previews it (Peek)
            keywords: `${name} ${type} record`,
        };
        if (type === "User") {
            // Users are also found by Username and Alias; rank those matches too.
            item.keywords += ` ${r.Username || ""} ${r.Alias || ""}`;
            item.sub = userSub(r);
            item.user = r; // raw fields for the "login" verb
        }
        return item;
    }

    function loadRecent() {
        if (!liveEnabled) return;
        ask("recent", {}, (resp) => {
            if (!resp || !liveEnabled) return;
            recentRecords = (resp.records || []).map(mapRecord);
            if (opened && !inputEl.value.trim()) render("");
        });
        // Recent Flow links open the version that was latest when they were
        // saved; move them to the current one.
        const flowIds = SFEN_RECENTS.flowIds(recents);
        if (!flowIds.length) return;
        ask("flowVersions", { flowIds }, (resp) => {
            const list = resp && liveEnabled && SFEN_RECENTS.updateFlows(host, resp.versions);
            if (!list) return;
            recents = list;
            if (opened && !inputEl.value.trim()) render("");
        });
    }

    // ---- Peek and hop ---------------------------------------
    // A record's preview ("peek" action), cached for the page's life (failed
    // ones until the next open). Returns it once loaded, else null and loads
    // it; then, while open, the results render again, or with onLoad, that.
    function peekRecord(id, onLoad) {
        const got = peekCache[id];
        if (got && typeof got === "object") return got;
        if (!got && liveEnabled) {
            peekCache[id] = "loading";
            ask("peek", { recordId: id }, (resp) => {
                peekCache[id] = resp ? resp.record : "failed";
                if (opened) onLoad ? onLoad() : render(inputEl.value);
            });
        }
        return null;
    }

    // The record you're on: its lookups, for the board's "This record" rows
    // and search. Refreshed when older than a minute, so edited lookups catch up.
    function loadHop() {
        const ctx = currentRecordContext();
        if (!ctx || !liveEnabled || (hopKey === ctx.id && Date.now() - hopAt < 60000)) return;
        if (hopKey !== ctx.id) hop = null;
        hopKey = ctx.id;
        hopAt = Date.now();
        ask("hop", { recordId: ctx.id }, (resp) => {
            if (hopKey !== ctx.id) return; // stale: another record since
            if (!resp) {
                hopAt = 0; // retry on the next open
                return;
            }
            hop = resp;
            if (opened && !activeVerb && !inputEl.value.trim()) render("");
        });
    }

    // Rows for the record you're on: the records it links to.
    function hopItems() {
        const ctx = currentRecordContext();
        if (!hop || !ctx || hopKey !== ctx.id) return [];
        return hop.lookups.map((l) => ({
            label: l.name,
            hint: l.label,
            group: GROUPS.RELATED,
            iconGroup: GROUPS.RECORD,
            url: recordUrl(l.type, l.id, hop.type),
            recordId: l.type === "RecordType" ? null : l.id, // a record type has no preview
            keywords: `${l.name} ${l.label} ${l.type}`,
            field: l.label, // searched as a second name (see compute)
        }));
    }

    let searchTimer = null;
    let searchSeq = 0; // bumped per request; a response for an older one is ignored
    let liveParts = {}; // latest results per action ("users", "search"); liveRecords joins them
    // Search records for `term`. A term under 2 characters (or "") just drops
    // the live results and any search still in flight.
    function runLiveSearch(term) {
        const seq = ++searchSeq;
        if (!liveEnabled || term.trim().length < 2) {
            liveRecords = [];
            liveParts = {};
            liveRecordsTerm = "";
            setLoading("search", false);
            return;
        }
        setLoading("search", true);
        // The "login" and "users" verbs list users only. Plain search asks for its 5 users
        // and the other records apart and shows each as it arrives: in an org
        // with many users the user query can be much the slower one. A part
        // keeps the previous term's rows until its answer replaces them.
        const usersOnly = activeVerb && (VERBS[activeVerb].kind === "login" || VERBS[activeVerb].kind === "users");
        const parts = usersOnly ? { users: {} } : { users: { limit: 5 }, search: {} };
        let pending = Object.keys(parts).length;
        Object.keys(parts).forEach((action) => {
            ask(action, { term, ...parts[action] }, (resp) => {
                if (seq !== searchSeq) return;
                if (--pending === 0) setLoading("search", false);
                // A failed search counts as "no matches" (so "login" doesn't wait forever).
                liveParts[action] = resp ? (resp.records || []).map(mapRecord) : [];
                liveRecords = (liveParts.users || []).concat(liveParts.search || []);
                liveRecordsTerm = term;
                if (opened) render(inputEl.value);
            });
        });
    }

    // ---- Recents persistence --------------------------------------------
    function pushRecent(item) {
        // Action rows (a pasted Id or link) have no name worth keeping.
        if (!item || item.group === GROUPS.ACTION || !SFEN_RECENTS.isSetup(item.url)) return;
        // Optimistic in-memory update; SFEN_RECENTS.record persists (setup-only).
        recents = recents.filter((r) => r.url !== item.url && !(item.flow && r.flow === item.flow));
        recents.unshift({ label: item.label, hint: item.hint, url: item.url, flow: item.flow });
        recents = recents.slice(0, 10);
        SFEN_RECENTS.record(item, host);
    }

    // ---- Often picked ----------------------------------------------------
    // Pick counts per org and url (chrome.storage.local "palettePicks"); the
    // org's push results up (pickBonus). Kept in memory and written with one
    // set, which still goes out when the pick navigates away.
    const PICKS_KEY = "palettePicks";
    const pickOrg = SFEN_ORGS.shortHost(host);
    let allPicks = null; // null until loaded
    const boost = (url) => pickBonus(allPicks && allPicks[pickOrg] ? allPicks[pickOrg][url] || 0 : 0);

    function recordPick(url) {
        if (!allPicks || !url) return;
        allPicks = addPick(allPicks, pickOrg, url);
        try {
            chrome.storage.local.set({ [PICKS_KEY]: allPicks });
        } catch (e) {
            /* context invalidated */
        }
    }

    // ---- Overlay UI ------------------------------------------------------
    let overlayHost, shadow, inputEl, listEl, footerEl, loaderEl, panelEl, orgEl, noticeEl, peekEl;
    let opened = false;
    let activeIndex = 0;
    let footerCount = "";
    let footerResetTimer = null;

    // The content script keeps running on already-open tabs after the
    // extension is reloaded/updated, but its chrome.* APIs then throw
    // "Extension context invalidated". Bail out cleanly in that case.
    function extAlive() {
        try {
            return !!(chrome.runtime && chrome.runtime.id);
        } catch (e) {
            return false;
        }
    }

    function applyTheme() {
        if (!extAlive() || !shadow) return;
        try {
            chrome.storage.sync.get(["settings"], (res) => {
                if (chrome.runtime.lastError || !res) return;
                const settings = SFEN_SETTINGS.normalize(res.settings);
                const theme = SFEN_SETTINGS.resolveTheme(settings);
                shadow.host.setAttribute("data-theme", theme);
                if (paletteDark !== (theme === "dark")) {
                    paletteDark = theme === "dark";
                    paintOrg();
                }
            });
        } catch (e) {
            /* context invalidated */
        }
    }

    function ensureOverlay() {
        // Rebuild if Lightning's SPA re-render detached our node — otherwise
        // open() would add the .open class to an orphan and "open" invisibly.
        if (overlayHost && document.documentElement.contains(overlayHost)) return;
        SFEN_SETTINGS.injectFonts();
        overlayHost = document.createElement("div");
        overlayHost.id = "sfen-cmdk-host";
        // Closed, and synthetic events are dropped, so page scripts can't
        // read the results or drive the palette (search, "Login as").
        shadow = overlayHost.attachShadow({ mode: "closed" });
        ["click", "mousedown", "keydown", "input"].forEach((type) =>
            shadow.addEventListener(type, (e) => {
                if (!e.isTrusted) e.stopImmediatePropagation();
            }, true)
        );

        // Inject styles inline so they apply synchronously on first paint.
        const style = document.createElement("style");
        style.textContent = PALETTE_CSS;
        shadow.appendChild(style);

        const backdrop = document.createElement("div");
        backdrop.className = "backdrop";
        backdrop.addEventListener("mousedown", (e) => {
            if (e.target === backdrop) close();
        });

        const panel = document.createElement("div");
        panel.className = "panel";
        panel.setAttribute("role", "combobox");
        panel.setAttribute("aria-expanded", "true");
        panelEl = panel;

        const searchWrap = document.createElement("div");
        searchWrap.className = "search-wrap";
        searchWrap.innerHTML = UI_ICONS.search;

        inputEl = document.createElement("input");
        inputEl.className = "search";
        inputEl.type = "text";
        inputEl.placeholder = DEFAULT_PLACEHOLDER;
        inputEl.setAttribute("spellcheck", "false");
        inputEl.setAttribute("autocomplete", "off");
        inputEl.setAttribute("role", "searchbox");
        inputEl.setAttribute("aria-controls", "sfen-results");
        inputEl.addEventListener("input", onInput);
        inputEl.addEventListener("keydown", onInputKeydown);

        loaderEl = document.createElement("div");
        loaderEl.className = "loader";

        orgEl = document.createElement("span");
        orgEl.className = "org";
        orgEl.innerHTML = '<span class="org-dot org-mark"></span><span class="org-name"></span><span class="org-tag"></span>';

        searchWrap.appendChild(inputEl);
        searchWrap.appendChild(loaderEl);
        searchWrap.appendChild(orgEl);
        paintOrg();

        listEl = document.createElement("ul");
        listEl.className = "results";
        listEl.id = "sfen-results";
        listEl.setAttribute("role", "listbox");

        footerEl = document.createElement("div");
        footerEl.className = "footer";
        footerEl.innerHTML = footerHtml();

        noticeEl = document.createElement("div");
        noticeEl.className = "notice";
        noticeEl.hidden = true;

        // The record preview (Peek) sits beside the results.
        peekEl = document.createElement("div");
        peekEl.className = "peek";
        peekEl.hidden = true;
        const body = document.createElement("div");
        body.className = "body";
        body.appendChild(listEl);
        body.appendChild(peekEl);

        panel.appendChild(searchWrap);
        panel.appendChild(noticeEl);
        panel.appendChild(body);
        panel.appendChild(footerEl);
        backdrop.appendChild(panel);
        shadow.appendChild(backdrop);
        document.body.appendChild(overlayHost);

        // Keep focus inside the palette while it's open.
        overlayHost.addEventListener("focusout", () => {
            if (opened) requestAnimationFrame(() => focusInput());
        });
    }

    // A footer hint: its keys as keycaps, then what they do.
    function keyHint(keys, text) {
        return `<span class="fk">${keys.map((k) => `<kbd>${k}</kbd>`).join("")}${text}</span>`;
    }

    // Footer key hints for the current mode; the right-aligned .footer-count
    // is filled separately (setFooterCount). Shift+Enter (background tab) is
    // left out for room; the Shortcuts list names it.
    function footerHtml() {
        const mod = MOD.replace("+", "");
        if (activeVerb && VERBS[activeVerb].kind === "org") {
            return (
                keyHint(["↑", "↓"], "Move") +
                keyHint(["↵"], "Open in new tab") +
                keyHint(["→"], "This page there") +
                keyHint(["Esc"], "Close") +
                '<span class="footer-count"></span>'
            );
        }
        if (activeVerb === "count") {
            return (
                keyHint(["↑", "↓"], "Move") +
                (fieldsTarget(inputEl.value) ? "" : keyHint(["↵"], "Count records")) +
                keyHint(["⌫"], "Back to search") +
                '<span class="footer-count"></span>'
            );
        }
        if (activeVerb && VERBS[activeVerb].kind === "limits") {
            return (
                "<span>Type to filter</span>" +
                keyHint(["⌫"], "Back to search") +
                keyHint(["Esc"], "Close") +
                '<span class="footer-count"></span>'
            );
        }
        if (activeVerb && VERBS[activeVerb].kind === "login") {
            return (
                keyHint(["↵"], "Log in") +
                keyHint([mod, "↵"], "Incognito") +
                keyHint(["⌫"], "Back to search") +
                '<span class="footer-count"></span>'
            );
        }
        return (
            keyHint(["↑", "↓"], "Move") +
            keyHint(["↵"], "Open") +
            keyHint([mod, "↵"], "New tab") +
            keyHint(["→"], '<span class="right-key">Actions</span>') +
            // In the "fields" and "list" verbs' object step, Tab completes the object instead.
            ((activeVerb === "fields" || activeVerb === "list") && !fieldsTarget(inputEl.value)
                ? keyHint(["Tab"], `Search ${activeVerb === "list" ? "list views" : "fields"}`)
                : keyHint(["Tab"], "Lock command")) +
            '<span class="footer-count"></span>'
        );
    }

    function resetFooter() {
        if (!footerEl) return;
        footerEl.innerHTML = footerHtml();
        setFooterCount(footerCount);
    }

    // Current org (saved name, else the cleaned-up My Domain) for the search
    // bar, plus the saved orgs and their tab colors for the "org" verb.
    function loadOrg() {
        if (!extAlive()) return;
        chrome.storage.sync.get({ quickOrgs: [], orgColors: {}, settings: null }, (res) => {
            if (chrome.runtime.lastError || !res) return;
            const short = SFEN_ORGS.shortHost(host);
            const all = Array.isArray(res.quickOrgs) ? res.quickOrgs : [];
            savedOrgs = all.filter((o) => o && SFEN_URL.isOrgHost(o.host));
            currentOrg = savedOrgs.find((o) => SFEN_ORGS.shortHost(o.host.toLowerCase()) === short) || null;
            tabColors = SFEN_SETTINGS.normalize(res.settings).orgTabColors;
            // Assigned over the full list, as everywhere else, so colors match.
            orgColorMap = SFEN_ORG_COLORS.assign(all, res.orgColors);
            orgName = currentOrg ? SFEN_ORGS.displayName(currentOrg) : SFEN_ORGS.defaultName(host);
            orgKind = SFEN_ORGS.orgType(currentOrg || { host });
            paintOrg();
            if (opened && activeVerb && VERBS[activeVerb].kind === "org") render(inputEl.value);
        });
    }

    // A saved org's color icon when tab colors are on, else its type dot.
    function orgMarker(org, size) {
        if (tabColors && org && orgColorMap[SFEN_ORG_COLORS.keyOf(org)]) {
            return SFEN_ORG_COLORS.tile(
                orgColorMap[SFEN_ORG_COLORS.keyOf(org)],
                SFEN_ORG_COLORS.initial(org),
                SFEN_ORGS.orgType(org) === "production",
                paletteDark,
                size
            );
        }
        const dot = document.createElement("span");
        dot.className = "org-dot " + SFEN_ORGS.orgType(org || { host });
        return dot;
    }

    // Hidden while inspecting a record (the record header names it instead).
    function paintOrg() {
        if (!orgEl) return;
        const marker = orgMarker(currentOrg, 14);
        marker.classList.add("org-mark");
        orgEl.querySelector(".org-mark").replaceWith(marker);
        orgEl.querySelector(".org-name").textContent = orgName;
        const tag = orgEl.querySelector(".org-tag");
        tag.className = "org-tag " + orgKind;
        tag.textContent = SFEN_ORGS.TYPES[orgKind] || "";
        orgEl.hidden = !orgName || !!(activeVerb && VERBS[activeVerb].kind === "inspect");
    }

    // The spinner shows while any request is pending ("search", "inspect",
    // "login"); setLoading(null) clears them all.
    const loadingKeys = new Set();
    function setLoading(key, on) {
        if (!key) loadingKeys.clear();
        else if (on) loadingKeys.add(key);
        else loadingKeys.delete(key);
        if (loaderEl) loaderEl.classList.toggle("on", loadingKeys.size > 0);
    }

    // True when "verb arg" is the start of a Setup page name ("login h" ->
    // Login History, "api usage" -> API Usage Notifications). An empty arg
    // never matches, so "record " still opens the inspector.
    function startsSetupName(verb, arg) {
        if (!arg.trim()) return false;
        const typed = (verb + " " + arg).toLowerCase().replace(/\s+/g, " ").trimEnd();
        // "org limits" finds the Org Limits result rather than the org verb.
        return SETUP_PAGES.some(([label]) => label.toLowerCase().startsWith(typed)) || "org limits".startsWith(typed);
    }

    function onInput() {
        if (!opened) return;
        shortcutsOpen = false; // typing leaves the Shortcuts list for the search
        expandedKey = null;
        clearTimeout(searchTimer);
        // Too short to search: drop the live results (and any search in flight) now.
        if (inputEl.value.trim().length < 2) runLiveSearch("");
        // A word verb followed by a space (e.g. "new ") switches to verb mode;
        // the rest becomes the argument. Typing the bare word still searches.
        // Verb words also start Setup names ("Login History", "Record Page
        // Settings"): while "verb arg" is the start of one, go back to (or stay
        // in) plain search. A verb locked with Tab or a hint never goes back.
        if (!activeVerb) {
            const m = inputEl.value.match(/^([a-zA-Z]+)\s+(.*)$/);
            const word = m && m[1].toLowerCase();
            const key = word && (VERB_SHORT[word] || word);
            if (m && VERBS[key] && !startsSetupName(word, m[2])) {
                setVerb(key, m[2], m[1]);
                return;
            }
            render(inputEl.value);
        } else if (autoVerbWord && startsSetupName(autoVerbWord, inputEl.value)) {
            const text = autoVerbWord + " " + inputEl.value;
            inputEl.value = text;
            clearVerb(); // renders the plain search
            inputEl.setSelectionRange(text.length, text.length);
        } else {
            render(inputEl.value);
        }
        // Verb results are local, except "login" and "users", which search users.
        if (activeVerb && VERBS[activeVerb].kind !== "login" && VERBS[activeVerb].kind !== "users") return;
        const term = inputEl.value;
        if (term.trim().length >= 2 && !pastedLink(term, host)) searchTimer = setTimeout(() => runLiveSearch(term), 140);
    }

    function highlight(label, query) {
        const q = query.trim().toLowerCase();
        const set = q ? new Set(highlightPositions(q, label)) : new Set();
        let html = "";
        for (let i = 0; i < label.length; i++) {
            // One <mark> per run of consecutive matches.
            if (set.has(i) && !set.has(i - 1)) html += "<mark>";
            html += escapeHtml(label[i]);
            if (set.has(i) && !set.has(i + 1)) html += "</mark>";
        }
        return html;
    }

    const flatResults = []; // one entry per visible .result row, in DOM order

    function groupHeader(text, count) {
        const h = document.createElement("li");
        h.className = "group-header";
        h.textContent = text;
        if (count) {
            const n = document.createElement("span");
            n.className = "group-count";
            n.textContent = count;
            h.appendChild(n);
        }
        h.setAttribute("aria-hidden", "true");
        return h;
    }

    // Build a .result <li>. A normal result passes the item; a ⋯ sub-action
    // passes isSub=true with a lighter shape ({label,hint}).
    function makeRow(item, idx, isSub) {
        const li = document.createElement("li");
        li.className = "result" + (isSub ? " subaction" : "");
        li.id = "sfen-opt-" + idx;
        li.dataset.index = idx;
        li.setAttribute("role", "option");

        const icon = document.createElement("span");
        icon.className = "icon";
        if (!isSub && item.org) icon.appendChild(orgMarker(item.org, 16));
        else if (isSub) icon.innerHTML = iconSvg(GROUPS.ACTION);
        else {
            const g = item.iconGroup || item.group;
            icon.innerHTML = iconSvg(g);
            icon.classList.add("tone-" + (ICON_TONES[g] || "setup"));
        }

        const wrap = document.createElement("span");
        wrap.className = "label-wrap";
        const label = document.createElement("span");
        label.className = "label";
        label.innerHTML = isSub
            ? escapeHtml(item.label)
            : highlight(item.label, item.highlightQuery != null ? item.highlightQuery : currentQuery);
        wrap.appendChild(label);
        if (!isSub && item.sub) {
            const sub = document.createElement("span");
            sub.className = "sub";
            sub.textContent = item.sub;
            wrap.appendChild(sub);
        }

        li.appendChild(icon);
        li.appendChild(wrap);
        // The API name sits at the right edge, so the label reads first.
        if (!isSub && item.api) {
            const api = document.createElement("span");
            api.className = "api mono";
            api.textContent = item.api;
            li.appendChild(api);
        }
        // Group headers already name Setup/object/bookmark rows; only records
        // (their object type), actions (e.g. "ID"), apps (console or not) and
        // fields (their data type) carry a trailing hint, as do the current
        // record's rows (the lookup's field).
        const hinted = [GROUPS.RECORD, GROUPS.ACTION, GROUPS.APP, GROUPS.FIELD, GROUPS.ORG, GROUPS.APEX, GROUPS.RELATED];
        if (!isSub && hinted.includes(item.group)) {
            const hint = document.createElement("span");
            hint.className = "hint";
            hint.textContent = item.hint || "";
            li.appendChild(hint);
        }

        if (!isSub && item.actions && item.actions.length) {
            const more = document.createElement("button");
            more.className = "more";
            more.type = "button";
            more.innerHTML = "<kbd>→</kbd>Actions";
            more.setAttribute("aria-label", "More actions");
            more.addEventListener("click", (e) => {
                e.stopPropagation();
                toggleExpand(item.url);
            });
            li.appendChild(more);
        } else if (!isSub && peekable(item)) {
            const more = document.createElement("button");
            more.className = "more";
            more.type = "button";
            more.innerHTML = "<kbd>→</kbd>Preview";
            more.setAttribute("aria-label", "Preview");
            more.addEventListener("click", (e) => {
                e.stopPropagation();
                setActive(idx);
                setPeek(!peekOpen);
            });
            li.appendChild(more);
        }

        const enter = document.createElement("span");
        enter.className = "enter";
        enter.innerHTML = "<kbd>↵</kbd>";
        li.appendChild(enter);

        li.addEventListener("mousemove", () => activeIndex !== idx && setActive(idx));
        li.addEventListener("click", (e) => choose(idx, e.metaKey || e.ctrlKey, e.shiftKey));
        return li;
    }

    // ---- Peek ------------------------------------------------------------
    // → on a record shows its key fields beside the results, and the preview
    // follows the selection until ← or Esc.
    function peekable(item) {
        return !!(item && !item.__action && item.recordId && !(item.actions && item.actions.length));
    }

    function setPeek(on) {
        peekOpen = on;
        clearTimeout(peekTimer);
        if (!peekEl) return;
        peekEl.hidden = !on;
        panelEl.classList.toggle("peek-mode", on);
        peekEntry = null;
        if (on) renderPeek();
        else peekEl.textContent = ""; // don't leave record values in the page
    }

    function peekNote(text) {
        const n = document.createElement("div");
        n.className = "peek-note";
        n.textContent = text;
        peekEl.appendChild(n);
    }

    function renderPeek() {
        if (!peekOpen || !peekEl) return;
        clearTimeout(peekTimer);
        peekEl.textContent = "";
        // Reaching the panel can cross rows that aren't records (the board's
        // right column), so the preview stays on the last record.
        if (peekable(flatResults[activeIndex])) peekEntry = flatResults[activeIndex];
        const i = flatResults.indexOf(peekEntry);
        const entry = flatResults[i];
        if (!peekable(entry)) return peekNote("Select a record to preview it.");
        if (!liveEnabled) return peekNote("Live org access is off (turn it on in Settings).");
        const id = entry.recordId;
        const rec = peekCache[id];
        if (rec === "failed") return peekNote("There's no preview for this record.");
        if (!rec || rec === "loading") {
            peekNote("Loading…");
            // Wait a moment, so moving through the list doesn't load every row.
            if (!rec) peekTimer = setTimeout(() => peekRecord(id, renderPeek), 150);
            return;
        }
        const head = document.createElement("div");
        head.className = "peek-head";
        head.innerHTML =
            `<span class="peek-tile">${UI_ICONS.record}</span>` +
            '<span class="peek-head-text"><div class="peek-title"></div><div class="peek-type"></div></span>';
        head.querySelector(".peek-title").textContent = rec.name;
        head.querySelector(".peek-type").textContent = rec.typeLabel;
        peekEl.appendChild(head);

        // Each field's name above its value.
        // A copy button shows a check (or turns red) for a moment.
        const copy = (b, text) => {
            if (b.classList.contains("copied") || b.classList.contains("failed")) return;
            const done = (cls) => {
                b.classList.add(cls);
                if (cls === "copied") b.innerHTML = UI_ICONS.check;
                setTimeout(() => {
                    b.classList.remove(cls);
                    b.innerHTML = UI_ICONS.copy;
                }, 1500);
            };
            writeClipboard(text).then(() => done("copied"), () => done("failed"));
        };

        const list = document.createElement("div");
        list.className = "peek-fields";
        // The Id comes last (a user's is already there, as User Id).
        const fields = rec.type === "User" ? rec.fields : rec.fields.concat({ label: "Record Id", value: rec.id, lookup: null });
        fields.forEach((f) => {
            const row = document.createElement("div");
            row.className = "peek-field";
            const label = document.createElement("span");
            label.className = "peek-label";
            label.textContent = f.label;
            let val;
            if (f.lookup) {
                // A lookup opens the record it points to.
                val = document.createElement("button");
                val.type = "button";
                val.className = "peek-link";
                val.addEventListener("click", () => {
                    close();
                    navigate(recordUrl(f.lookup.type, f.lookup.id, rec.type), false);
                });
            } else {
                val = document.createElement("span");
                val.className = "peek-val" + (f.value ? "" : " dim");
            }
            val.textContent = f.value || "Empty";
            row.append(label, val);
            if (f.value && !f.lookup) {
                // Hovering a value shows a button that copies it.
                const b = document.createElement("button");
                b.type = "button";
                b.className = "peek-icon";
                b.title = "Copy " + f.label;
                b.setAttribute("aria-label", b.title);
                b.innerHTML = UI_ICONS.copy;
                b.addEventListener("click", () => copy(b, f.value));
                row.appendChild(b);
            }
            list.appendChild(row);
        });
        peekEl.appendChild(list);

        // Labeled buttons, at the bottom while the fields scroll. Enter or a
        // click on the row already opens the record, so there's no Open.
        const actions = document.createElement("div");
        actions.className = "peek-actions";
        const addRow = (buttons) => {
            const row = document.createElement("div");
            row.className = "peek-row";
            buttons.forEach(([icon, text, onClick]) => {
                const b = document.createElement("button");
                b.type = "button";
                b.className = "peek-btn";
                b.innerHTML = (icon ? UI_ICONS[icon] : "") + "<span></span>";
                b.lastChild.textContent = text;
                b.addEventListener("click", () => onClick(b));
                row.appendChild(b);
            });
            actions.appendChild(row);
        };
        if (rec.type === "User") {
            addRow([
                [null, "Login as", () => runAction({ kind: "loginAs", userId: rec.id, incognito: false })],
                [null, "Login as · Incognito", () => runAction({ kind: "loginAs", userId: rec.id, incognito: true })],
            ]);
        }
        const copyLink = (b) =>
            writeClipboard(lightningOrigin() + entry.url).then(() => {
                b.lastChild.textContent = "Copied";
                setTimeout(() => (b.lastChild.textContent = "Copy link"), 1500);
            }, () => flashFooter("Copy failed"));
        addRow([
            ["newTab", "New tab", () => choose(i, true)],
            ["link", "Copy link", copyLink],
        ]);
        peekEl.appendChild(actions);
    }

    // Append result rows to `container`, expanding ⋯ actions inline for the row
    // whose url matches expandedKey. Registers each visible row in flatResults.
    function renderRows(container, items) {
        items.forEach((item) => {
            const i = flatResults.length;
            flatResults.push(item);
            container.appendChild(makeRow(item, i, false));
            if (expandedKey && item.url === expandedKey && item.actions) {
                item.actions.forEach((action) => {
                    const si = flatResults.length;
                    flatResults.push({ __action: action });
                    container.appendChild(makeRow(action, si, true));
                });
            }
        });
    }

    function render(query) {
        currentQuery = query;
        listEl.innerHTML = "";
        flatResults.length = 0;
        setFooterCount("");
        paintOrg();
        if (shortcutsOpen) renderShortcuts();
        else if (activeVerb) renderVerb(query);
        else if (query.trim()) renderList(query);
        else renderBoard();
    }

    // ---- Command verbs ---------------------------------------------------
    function objectSource() {
        return liveObjects && liveObjects.length
            ? liveObjects
            : FALLBACK_OBJECTS.map((n) => ({ api: n, label: n }));
    }

    // typedWord: the verb as typed when "word " switched it on (it can then
    // switch back to plain search); omit it to lock the verb (Tab, hint click).
    function setVerb(key, arg, typedWord) {
        if (!VERBS[key]) return;
        activeVerb = key;
        autoVerbWord = typedWord || null;
        inputEl.value = arg || "";
        const kind = VERBS[key].kind;
        inputEl.placeholder =
            kind === "inspect"
                ? "Filter fields…"
                : kind === "login"
                ? "Type a user's name…"
                : kind === "app"
                ? "Type an app name…"
                : kind === "org"
                ? "Type an org name…"
                : kind === "limits"
                ? "Filter limits…"
                : kind === "users"
                ? "Type a user's name…"
                : kind === "admin"
                ? `Filter ${VERBS[key].label.toLowerCase()}…`
                : "Type an object name…";
        renderChip();
        resetFooter();
        if (kind === "inspect") fetchInspect();
        if (kind === "login" || kind === "users") runLiveSearch(inputEl.value);
        render(inputEl.value);
        focusInput();
    }

    function clearVerb() {
        activeVerb = null;
        autoVerbWord = null;
        inspectKey = null;
        inspectRecord = null;
        setLoading("inspect", false);
        fieldsKey = null;
        setLoading("fields", false);
        listViewsKey = null;
        setLoading("listViews", false);
        countKey = null;
        setLoading("count", false);
        recentKey = null;
        setLoading("recent", false);
        setLoading("limits", false);
        inputEl.placeholder = DEFAULT_PLACEHOLDER;
        renderChip();
        resetFooter();
        render(inputEl.value);
    }

    function renderChip() {
        const wrap = inputEl.parentElement; // .search-wrap
        let chip = wrap.querySelector(".scope-chip");
        if (!activeVerb) {
            if (chip) chip.remove();
            return;
        }
        if (!chip) {
            // Clicking the chip clears the verb (with Esc / Backspace as backups).
            chip = document.createElement("button");
            chip.type = "button";
            chip.className = "scope-chip";
            chip.title = "Remove (Esc)";
            chip.addEventListener("click", (e) => {
                e.preventDefault();
                clearVerb();
                focusInput();
            });
            wrap.insertBefore(chip, inputEl);
        }
        chip.innerHTML = '<span class="chip-label"></span><span class="chip-x">' + UI_ICONS.close + "</span>";
        // For the "record" verb show the live record's object name (e.g. Account);
        // object verbs keep their static label (New / List / Fields).
        const v = VERBS[activeVerb];
        let label = v.label;
        if (v.kind === "inspect") {
            const ctx = currentRecordContext();
            label = ctx ? "This " + ctx.type : "Record";
        }
        chip.querySelector(".chip-label").textContent = label;
    }

    function renderVerb(query) {
        if (VERBS[activeVerb].kind === "inspect") {
            renderInspector();
            return;
        }
        if (VERBS[activeVerb].kind === "login") {
            renderLogin(query);
            return;
        }
        if (VERBS[activeVerb].kind === "app") {
            renderApps(query);
            return;
        }
        if (VERBS[activeVerb].kind === "org") {
            renderOrgs(query);
            return;
        }
        if (VERBS[activeVerb].kind === "recent") {
            renderRecentVerb(query);
            return;
        }
        if (VERBS[activeVerb].kind === "limits") {
            renderLimits(query);
            return;
        }
        if (VERBS[activeVerb].kind === "admin") {
            renderAdminVerb(VERBS[activeVerb], query);
            return;
        }
        if (VERBS[activeVerb].kind === "users") {
            renderUsers(query);
            return;
        }
        if (activeVerb === "fields" || activeVerb === "list" || activeVerb === "count") {
            resetFooter(); // the Tab hint differs between the object and field steps
            const target = fieldsTarget(query);
            if (target) {
                ({ list: renderListViews, fields: renderFields, count: renderCounts })[activeVerb](target.obj, target.text);
                return;
            }
        }
        panelEl.classList.remove("board-mode");
        const items = objectVerbEntries(VERBS[activeVerb].action, objectSource(), query, boost);
        // With nothing typed, the object of the page you're on comes first.
        const here = !query.trim() && currentObject();
        if (here) items.sort((a, b) => (b.objectApi === here.obj.api) - (a.objectApi === here.obj.api));
        items.length = Math.min(items.length, 24);
        if (!items.length) return showEmpty("No objects");
        listEl.appendChild(groupHeader("Objects"));
        renderRows(listEl, items);
        setActive(0);
    }

    // "app" verb: the user's apps matching the query, in App Launcher order
    // when it's empty.
    function renderApps(query) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        if (!appItems) return showEmpty(appsRequested ? "Loading apps…" : "Couldn't load apps");
        const q = query.trim();
        const items = q
            ? appItems
                  .map((item) => ({ item, sc: SFEN_URL.matchScore(q, item.label, item.keywords) }))
                  .filter((s) => s.sc >= 0)
                  .sort((a, b) => b.sc - a.sc)
                  .map((s) => s.item)
            : appItems;
        if (!items.length) return showEmpty(q ? `No apps match “${q}”` : "No apps");
        listEl.appendChild(groupHeader(GROUPS.APP));
        renderRows(listEl, items);
        setActive(0);
    }

    // "recent" verb: your last viewed records (settings.recentCount), or the
    // best matching object's once one is typed. With none there's nothing to show.
    function renderRecentVerb(query) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        const q = query.trim();
        let obj = null;
        let bestScore = -1;
        if (q) {
            objectSource().forEach((o) => {
                const sc = objectScore(q.toLowerCase(), o);
                if (sc > bestScore) {
                    obj = o;
                    bestScore = sc;
                }
            });
            if (!obj) return showEmpty(`No objects match “${q}”`);
        }
        const records = obj ? recentCache[obj.api] : recentRecords;
        if (!records) {
            loadObjectRecent(obj.api);
            return showEmpty("Loading recent records…");
        }
        if (!records.length) return;
        listEl.appendChild(groupHeader(obj ? `Recent ${obj.plural || obj.label || obj.api}` : "Recent records"));
        renderRows(listEl, records.slice(0, recentCount));
        setActive(0);
    }

    // Org Limits: a bar per limit, most used first, filtered by name. The
    // rows only show numbers: Enter does nothing on them.
    function renderLimits(query) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        if (limitsData === "failed") {
            return showEmpty("Couldn't load limits", "Seeing org limits needs the View Setup and Configuration permission.");
        }
        if (!limitsData) {
            loadLimits();
            return showEmpty("Loading limits…");
        }
        const q = query.trim();
        const rows = sortLimits(limitsData).filter((l) => !q || SFEN_URL.matchScore(q, l.label, l.name) >= 0);
        setFooterCount(`${rows.length} of ${limitsData.length} limits`);
        if (!rows.length) return showEmpty(q ? `No limits match “${q}”` : "No limits");
        listEl.appendChild(groupHeader("Most used first"));
        rows.forEach((l) => listEl.appendChild(limitRow(l)));
    }

    function limitRow(l) {
        const li = document.createElement("li");
        // Red from 80% used, amber from 50%.
        li.className = "limit " + (l.pct >= 0.8 ? "high" : l.pct >= 0.5 ? "mid" : "low") + (l.used ? "" : " unused");
        li.title = l.name;
        li.innerHTML = '<span class="limit-name"></span><span class="limit-bar"><span></span></span><span class="limit-num"></span><span class="limit-pct"></span>';
        li.querySelector(".limit-name").textContent = l.label;
        li.querySelector(".limit-bar span").style.width = Math.min(100, l.pct * 100) + "%";
        li.querySelector(".limit-num").textContent = `${l.used.toLocaleString()} / ${l.max.toLocaleString()}`;
        li.querySelector(".limit-pct").textContent = l.used && l.pct < 0.01 ? "<1%" : Math.round(l.pct * 100) + "%";
        return li;
    }

    function loadLimits() {
        if (limitsLoading) return;
        limitsLoading = true;
        setLoading("limits", true);
        ask("limits", {}, (resp) => {
            limitsLoading = false;
            setLoading("limits", false);
            limitsData = resp ? resp.limits || [] : "failed";
            if (opened && activeVerb === "limits") render(inputEl.value);
        });
    }

    // "org" verb: saved orgs, pinned first. Enter opens the org in a new tab;
    // → offers the page you're on in that org, to compare the two.
    function renderOrgs(query) {
        panelEl.classList.remove("board-mode");
        if (!savedOrgs.length) {
            return showEmpty(
                "No saved orgs yet",
                "Save the orgs you use in the Orgs tab of the Navigator popup, then switch between them here."
            );
        }
        const q = query.trim();
        const ordered = savedOrgs.filter((o) => o.pinned).concat(savedOrgs.filter((o) => !o.pinned));
        const scored = ordered
            .map((o) => {
                const type = SFEN_ORGS.TYPES[SFEN_ORGS.orgType(o)];
                return { o, sc: q ? SFEN_URL.matchScore(q, SFEN_ORGS.displayName(o), `${o.host} ${type}`) : 0 };
            })
            // Letters scattered across the host ("uat" in "momentum-dx.scratch…")
            // aren't a match: keep name matches and words of the host or type.
            .filter((r) => (q ? r.sc >= 100 : true));
        if (q) scored.sort((a, b) => b.sc - a.sc);
        if (!scored.length) return showEmpty(`No orgs match “${q}”`);
        listEl.appendChild(groupHeader(GROUPS.ORG));
        renderRows(listEl, scored.map((r) => orgItem(r.o)));
        setActive(0);
    }

    function orgItem(org) {
        const name = SFEN_ORGS.displayName(org);
        const here = org === currentOrg;
        const samePage = here ? null : SFEN_ORGS.samePageUrl(org, location.href);
        return {
            label: name,
            sub: `${SFEN_ORGS.TYPES[SFEN_ORGS.orgType(org)]} · ${SFEN_ORGS.shortHost(org.host)}`,
            hint: here ? "This tab" : "",
            group: GROUPS.ORG,
            url: "https://" + org.host + "/",
            newTab: true,
            org,
            actions: samePage
                ? [{ label: `This page in ${name}`, hint: "Same page", kind: "nav", url: samePage, newTab: true }]
                : null,
        };
    }

    // "fields" and "list" verbs, second step: "<object> <text>" searches that
    // object's fields or list views. The object is the longest run of leading
    // words that exactly names one (API name first, then label or plural
    // label), else the best match for the first word.
    // While the text is still the start of a multi-word object label ("invoice
    // l" -> Invoice Line) it stays in the object step. Returns { obj, text } or
    // null for the object step.
    function fieldsTarget(arg) {
        const text = arg.replace(/^\s+/, "");
        if (!/\S\s/.test(text)) return null;
        const lower = text.toLowerCase();
        const objects = objectSource();
        const labelOf = (o) => (o.label || o.api).toLowerCase();
        if (!/\s$/.test(text) && objects.some((o) => labelOf(o).startsWith(lower))) return null;
        const cuts = []; // word ends, longest head first
        for (let i = text.length - 1; i > 0; i--) {
            if (/\s/.test(text[i]) && /\S/.test(text[i - 1])) cuts.push(i);
        }
        for (const i of cuts) {
            const head = lower.slice(0, i);
            const obj =
                objects.find((o) => o.api.toLowerCase() === head) ||
                objects.find((o) => labelOf(o) === head || (o.plural || "").toLowerCase() === head);
            if (obj) return { obj, text: text.slice(i).trim() };
        }
        const first = cuts[cuts.length - 1];
        let best = null;
        let bestScore = -1;
        objects.forEach((o) => {
            const sc = objectScore(lower.slice(0, first), o);
            if (sc > bestScore) {
                best = o;
                bestScore = sc;
            }
        });
        return best ? { obj: best, text: text.slice(first).trim() } : null;
    }

    function renderFields(obj, text) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        const name = obj.label || obj.api;
        const fields = fieldsCache[obj.api];
        if (!fields) {
            if (fieldsFailed[obj.api]) return showEmpty(`Couldn't load fields for ${name}`);
            loadFields(obj.api);
            return showEmpty("Loading fields…");
        }
        const q = text.trim();
        const scored = [];
        fields.forEach((f) => {
            const sc = q ? SFEN_URL.matchScore(q, f.label, f.api) : 0;
            // Package fields (SBQQ__Discount__c) after the org's own.
            if (sc >= 0) scored.push({ f, sc: sc - (SFEN_URL.namespaceOf(f.api) ? PACKAGE_PENALTY : 0) });
        });
        scored.sort((a, b) => b.sc - a.sc || String(a.f.label).localeCompare(String(b.f.label)));
        setFooterCount(`${scored.length} of ${fields.length} fields`);
        if (!scored.length) return showEmpty(`No ${name} fields match “${q}”`);
        listEl.appendChild(groupHeader(`${name} fields`));
        renderRows(
            listEl,
            scored.slice(0, 50).map(({ f }) => ({
                label: f.label || f.api,
                api: f.api,
                hint: f.type,
                group: GROUPS.FIELD,
                url: `/lightning/setup/ObjectManager/${obj.api}/FieldsAndRelationships/${f.key}/view`,
                highlightQuery: q,
            }))
        );
        setActive(0);
    }

    function renderListViews(obj, text) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        const name = obj.label || obj.api;
        const views = listViewsCache[obj.api];
        if (views === "failed") return showEmpty(`Couldn't load list views for ${name}`);
        if (!views) {
            loadListViews(obj.api);
            return showEmpty("Loading list views…");
        }
        const q = text.trim();
        // "list account 2": your 2nd last viewed Account comes first, above
        // any list views matching "2".
        const rec = /^[1-5]$/.test(q) && (listRecentCache[obj.api] || [])[q - 1];
        const scored = views
            .map((v) => ({ v, sc: q ? SFEN_URL.matchScore(q, v.label, v.api) : 0 }))
            .filter((s) => s.sc >= 0)
            .sort((a, b) => b.sc - a.sc || a.v.label.localeCompare(b.v.label));
        setFooterCount(`${scored.length} of ${views.length} list views`);
        if (!scored.length && !rec) return showEmpty(`No ${name} list views match “${q}”`);
        if (rec) {
            listEl.appendChild(groupHeader(`Last viewed ${name} #${q}`));
            renderRows(listEl, [
                { label: rec.name, hint: name, group: GROUPS.RECORD, url: recordUrl(obj.api, rec.id), recordId: rec.id },
            ]);
        }
        if (scored.length) {
            listEl.appendChild(groupHeader(`${name} list views`));
            renderRows(
                listEl,
                scored.slice(0, 50).map(({ v }) => ({
                    label: v.label,
                    group: GROUPS.OBJECT,
                    url: `/lightning/o/${obj.api}/list?filterName=${v.id}`,
                    highlightQuery: q,
                }))
            );
        }
        setActive(0);
    }

    // "count" verb, second step: the object's total, then each record type's.
    // The rows only show numbers: Enter does nothing on them.
    function renderCounts(obj, text) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        const name = obj.label || obj.api;
        const plural = obj.plural || name;
        const counts = countCache[obj.api];
        if (counts === "failed") return showEmpty(`Couldn't count ${plural}`);
        if (!counts) {
            loadCounts(obj.api);
            return showEmpty(`Counting ${plural}…`);
        }
        const q = text.trim();
        const row = (label, n, sub) => ({
            label,
            sub,
            hint: n.toLocaleString(),
            group: GROUPS.RECORD,
            highlightQuery: q,
        });
        const types = counts.recordTypes
            .map((t) => ({ t, sc: q ? SFEN_URL.matchScore(q, t.name, "") : 0 }))
            .filter((s) => s.sc >= 0)
            .sort((a, b) => b.sc - a.sc || b.t.count - a.t.count || a.t.name.localeCompare(b.t.name))
            .map(({ t }) => row(t.name, t.count, t.active ? "" : "Inactive"));
        if (counts.recordTypes.length) setFooterCount(`${counts.recordTypes.length} record types`);
        if (q && !types.length) return showEmpty(`No ${name} record types match “${q}”`);
        listEl.appendChild(groupHeader(`${name} records`));
        renderRows(listEl, (q ? [] : [row(`All ${plural}`, counts.total)]).concat(types));
        listEl.querySelectorAll(".enter").forEach((el) => el.remove()); // no ↵ to offer
        setActive(0);
    }

    // "login" verb: users from the "users" lookup. Enter logs in as the user in a
    // new tab (like the ⋯ "Login as — new tab" action); Ctrl/⌘+Enter uses Incognito.
    function renderLogin(query) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        if (query.trim().length < 2) return showEmpty("Type a name to find a user");
        const users = liveRecords.filter((i) => i.user);
        if (!users.length) {
            return showEmpty(liveRecordsTerm === query ? `No users match “${query.trim()}”` : "Searching users…");
        }
        listEl.appendChild(groupHeader("Users"));
        users.forEach((item) => listEl.appendChild(makeLoginRow(item)));
        setActive(0);
    }

    // "users" verb: like "login", but Enter opens the user's record and →
    // previews them.
    function renderUsers(query) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        const q = query.trim();
        if (q.length < 2) {
            // Too short to search: the active users who logged in last, filtered by a first letter.
            if (!activeUsers) {
                loadActiveUsers();
                return showEmpty("Loading users…");
            }
            const shown = q ? activeUsers.filter((i) => SFEN_URL.matchScore(q, i.label, i.keywords) >= 0) : activeUsers;
            if (!shown.length) return showEmpty("Type a name to find a user");
            listEl.appendChild(groupHeader("Active users, last logged in first"));
            renderRows(listEl, shown);
            setActive(0);
            return;
        }
        const users = liveRecords.filter((i) => i.user);
        if (!users.length) {
            return showEmpty(liveRecordsTerm === query ? `No users match “${query.trim()}”` : "Searching users…");
        }
        listEl.appendChild(groupHeader("Users"));
        renderRows(listEl, users);
        setActive(0);
    }

    // "flows", "profiles", "permsets" and "apex": every item of that kind from
    // the "admin" lookup, or the ones matching what's typed. Enter opens one.
    function renderAdminVerb(verb, query) {
        panelEl.classList.remove("board-mode");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        if (!adminLoaded) {
            // A failed ask waits for the next open, not every keystroke.
            if (adminFailed) return showEmpty(`Couldn't load ${verb.label.toLowerCase()}`, "Close and reopen the palette to try again.");
            loadAdmin();
            return showEmpty("Loading…");
        }
        // Managed-package code is hidden in Setup, so package Apex shows only
        // with the header's "Show package code" ticked.
        const apex = verb.group === GROUPS.APEX;
        const all = adminItems.filter((i) => i.group === verb.group && (!apex || showPackageApex || !i.pkg));
        const q = query.trim();
        // Matches by score; ties, and the list with nothing typed, stay newest first.
        const items = q
            ? all
                  .map((item) => ({ item, sc: SFEN_URL.matchScore(q, item.label, item.keywords) }))
                  .filter((s) => s.sc >= 0)
                  .sort((a, b) => b.sc - a.sc)
                  .map((s) => s.item)
            : all;
        const shown = items.slice(0, q ? 50 : 20);
        setFooterCount(`${shown.length} of ${all.length}`);
        const title = q ? verb.label : `${verb.label}, last modified first`;
        // The apex header always shows, so its checkbox can be ticked with no matches.
        if (apex) listEl.appendChild(apexHeader(title));
        if (!items.length) return showEmpty(q ? `No ${verb.label.toLowerCase()} match “${q}”` : `No ${verb.label.toLowerCase()}`);
        if (!apex) listEl.appendChild(groupHeader(title));
        renderRows(listEl, shown.map((item) => ({ ...item, highlightQuery: q })));
        setActive(0);
    }

    // The apex list's header with its "Show package code" checkbox, which
    // saves settings.showPackageApex.
    function apexHeader(title) {
        const h = groupHeader(title);
        h.removeAttribute("aria-hidden");
        const label = document.createElement("label");
        label.className = "pkg-toggle";
        const box = document.createElement("input");
        box.type = "checkbox";
        box.checked = showPackageApex;
        box.addEventListener("change", () => {
            showPackageApex = box.checked;
            render(inputEl.value);
            focusInput();
            if (!extAlive()) return;
            chrome.storage.sync.get("settings", (res) => {
                if (chrome.runtime.lastError) return;
                const s = SFEN_SETTINGS.normalize(res && res.settings);
                s.showPackageApex = showPackageApex;
                chrome.storage.sync.set({ settings: s });
            });
        });
        label.append(box, "Show package code");
        h.appendChild(label);
        return h;
    }

    function loadActiveUsers() {
        if (activeUsersLoading) return;
        activeUsersLoading = true;
        setLoading("activeUsers", true);
        ask("users", { term: "", active: true }, (resp) => {
            activeUsersLoading = false;
            setLoading("activeUsers", false);
            activeUsers = ((resp && resp.records) || []).map(mapRecord);
            if (opened && activeVerb && VERBS[activeVerb].kind === "users") render(inputEl.value);
        });
    }

    // Inactive users render dimmed and aren't selectable (not in flatResults).
    function makeLoginRow(item) {
        const u = item.user;
        const inactive = u.IsActive === false;
        const li = document.createElement("li");
        li.className = "result login-row" + (inactive ? " disabled" : "");
        li.setAttribute("role", "option");
        li.innerHTML =
            '<span class="icon">' + iconSvg(GROUPS.PROFILE) + "</span>" +
            '<span class="label-wrap"><span class="label"></span><span class="sub"></span></span>';
        li.querySelector(".label").innerHTML = highlight(item.label, currentQuery);
        li.querySelector(".sub").textContent = [u.ProfileName, inactive ? "Inactive" : u.Username]
            .filter(Boolean)
            .join(" · ");
        if (inactive) {
            li.setAttribute("aria-disabled", "true");
            const hint = document.createElement("span");
            hint.className = "hint";
            hint.textContent = "Inactive users can't be logged in as";
            li.appendChild(hint);
            return li;
        }
        const idx = flatResults.length;
        flatResults.push({ label: item.label, loginUserId: u.Id });
        li.id = "sfen-opt-" + idx;
        li.dataset.index = idx;
        [["Log in", false], ["Incognito", true]].forEach(([text, incognito]) => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "login-btn" + (incognito ? " secondary" : "");
            btn.textContent = text;
            if (incognito)
                btn.title = "Opens a private window. Your session is passed in the link, so it stays in that window's history until you close it.";
            btn.addEventListener("click", (e) => {
                e.stopPropagation();
                runAction({ kind: "loginAs", userId: u.Id, incognito });
            });
            li.appendChild(btn);
        });
        li.addEventListener("mousemove", () => setActive(idx));
        li.addEventListener("click", (e) => choose(idx, e.metaKey || e.ctrlKey));
        return li;
    }

    // The object of the page you're on: a record or list (/lightning/r|o/...)
    // or its pages in Object Manager (setup: true). null elsewhere, and for
    // types that aren't objects in Object Manager (reports, dashboards).
    function currentObject() {
        const m = location.pathname.match(/^\/lightning\/(r|o|setup\/ObjectManager)\/([A-Za-z][A-Za-z0-9_]*)\//);
        const ctx = currentRecordContext(); // also names the type of /lightning/r/{Id}/view
        const api = (ctx ? ctx.type : m ? m[2] : "").toLowerCase();
        const obj = api && objectSource().find((o) => o.api.toLowerCase() === api);
        return obj ? { obj, setup: !!m && m[1].length > 1 } : null;
    }

    // Parse the current record's type + Id from a /lightning/r/{Type}/{Id}/...
    // URL, for the record inspector. A record just created opens at
    // /lightning/r/{Id}/view instead; its Id's prefix names the object then.
    function currentRecordContext() {
        const m = location.pathname.match(/\/lightning\/r\/([^/]+)\/([^/]+)\//);
        if (m) return { type: m[1], id: m[2] };
        const bare = location.pathname.match(/^\/lightning\/r\/([A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?)\/view$/);
        const obj = bare && objectSource().find((o) => o.prefix === bare[1].slice(0, 3));
        return obj ? { type: obj.api, id: bare[1] } : null;
    }

    function fetchInspect() {
        const ctx = currentRecordContext();
        if (!ctx || !liveEnabled) return;
        // Field labels (cached per org + object); on failure rows keep API names only.
        const dKey = host + "/" + ctx.type;
        if (!describeCache[dKey]) {
            ask("describe", { recordType: ctx.type }, (resp) => {
                if (!resp) return;
                const labels = {};
                (resp.fields || []).forEach((f) => (labels[f.name] = f.label));
                describeCache[dKey] = labels;
                if (opened && activeVerb && VERBS[activeVerb].kind === "inspect")
                    render(inputEl.value);
            });
        }
        const key = ctx.type + "/" + ctx.id;
        if (inspectKey === key && inspectRecord) return; // already loaded
        inspectKey = key;
        inspectRecord = null;
        setLoading("inspect", true);
        ask("record", { recordType: ctx.type, recordId: ctx.id }, (resp) => {
            if (inspectKey !== key) return; // stale: the verb was cleared or reopened
            setLoading("inspect", false);
            inspectRecord = resp ? resp.record : null;
            if (opened && activeVerb && VERBS[activeVerb].kind === "inspect")
                render(inputEl.value);
        });
    }

    function renderInspector() {
        panelEl.classList.remove("board-mode");
        const ctx = currentRecordContext();
        if (!ctx) return showEmpty("Open a record first, then run “record” to inspect it.");
        if (!liveEnabled) return showEmpty("Live org access is off (enable it in Settings).");
        if (!inspectRecord) return showEmpty("Loading record…");

        const wrap = document.createElement("div");
        wrap.className = "inspector";
        const head = document.createElement("div");
        head.className = "insp-head";
        head.innerHTML =
            '<span class="insp-title-wrap"><span class="insp-title"></span>' +
            '<span class="insp-type"><span class="insp-type-name"></span> · <span class="mono"></span></span></span>' +
            '<button class="insp-action" type="button">Copy Id</button>' +
            '<button class="insp-action" type="button">Copy JSON</button>' +
            '<button class="insp-action" type="button" title="Copy only the fields that have a value">Copy JSON (no blanks)</button>';
        head.querySelector(".insp-title").textContent =
            inspectRecord.Name || inspectRecord.CaseNumber || ctx.id;
        head.querySelector(".insp-type-name").textContent = ctx.type;
        head.querySelector(".insp-type .mono").textContent = ctx.id;
        const [copyIdBtn, copyJsonBtn, copyFilledBtn] = head.querySelectorAll(".insp-action");
        copyIdBtn.addEventListener("click", () =>
            copyWithFeedback(copyIdBtn, inspectRecord.Id || ctx.id)
        );
        copyJsonBtn.addEventListener("click", () => {
            const data = { ...inspectRecord };
            delete data.attributes;
            copyWithFeedback(copyJsonBtn, JSON.stringify(data, null, 2));
        });
        copyFilledBtn.addEventListener("click", () => {
            const data = {};
            Object.keys(inspectRecord).forEach((k) => {
                const v = inspectRecord[k];
                if (k !== "attributes" && v !== null && v !== "") data[k] = v;
            });
            copyWithFeedback(copyFilledBtn, JSON.stringify(data, null, 2));
        });
        wrap.appendChild(head);

        const labels = describeCache[host + "/" + ctx.type] || {};
        const filter = (inputEl.value || "").trim().toLowerCase();
        const keys = Object.keys(inspectRecord).filter((k) => k !== "attributes");
        const shown = keys.filter(
            (k) =>
                !filter ||
                k.toLowerCase().includes(filter) ||
                (labels[k] || "").toLowerCase().includes(filter)
        );
        inputEl.placeholder = `Filter ${keys.length} fields`;
        setFooterCount(`${shown.length} of ${keys.length} fields`);
        shown.forEach((k) => {
            const v = inspectRecord[k];
            const val =
                v === null || v === undefined
                    ? "—"
                    : typeof v === "object"
                    ? JSON.stringify(v)
                    : String(v);
            const row = document.createElement("div");
            row.className = "insp-row";
            row.innerHTML =
                '<span class="insp-key mono"></span><span class="insp-val"></span>' +
                '<button class="insp-copy" type="button">Copy</button>';
            const keyEl = row.querySelector(".insp-key");
            if (labels[k]) {
                // Label above, API name below in mono.
                keyEl.classList.add("labeled");
                keyEl.innerHTML = '<span class="insp-label"></span><span class="insp-api mono"></span>';
                keyEl.querySelector(".insp-label").textContent = labels[k];
                keyEl.querySelector(".insp-api").textContent = k;
            } else {
                keyEl.textContent = k;
            }
            const valEl = row.querySelector(".insp-val");
            const empty = v === null || v === undefined;
            valEl.textContent = empty ? "Empty" : val;
            valEl.classList.toggle("dim", empty);
            const copyBtn = row.querySelector(".insp-copy");
            copyBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                copyWithFeedback(copyBtn, val);
            });
            wrap.appendChild(row);
        });
        listEl.appendChild(wrap);
    }

    // navigator.clipboard.writeText as a promise that also rejects when the
    // clipboard API is missing or throws.
    function writeClipboard(text) {
        try {
            return navigator.clipboard.writeText(text);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    // Copy `text`, briefly swapping the button's label for a green "Copied"
    // (or a red "Copy failed").
    function copyWithFeedback(btn, text) {
        if (btn.classList.contains("copied") || btn.classList.contains("failed")) return;
        const label = btn.textContent;
        const show = (msg, cls) => {
            btn.textContent = msg;
            btn.classList.add(cls);
            setTimeout(() => {
                btn.textContent = label;
                btn.classList.remove(cls);
            }, 1500);
        };
        writeClipboard(text).then(
            () => show("Copied", "copied"),
            () => show("Copy failed", "failed")
        );
    }

    function renderList(query) {
        panelEl.classList.remove("board-mode");
        const results = compute(query);
        // A pasted link to one record of another org can't open here.
        const link = pastedLink(query, host);
        if (link && !link.path) {
            return showEmpty(
                "This link is to a record in another org",
                "A record exists in one org only. Links to Setup pages and lists open here."
            );
        }
        if (results.length === 0) {
            const verbs =
                'Try fewer words, or start with <span class="mono">new</span>, ' +
                '<span class="mono">list</span> or <span class="mono">fields</span>.';
            return showEmpty(
                `No matches for “${query.trim()}”`,
                (liveEnabled
                    ? "Search looks through Setup, objects, records, apps, flows, profiles, permission sets, Apex, custom metadata types and your bookmarks. "
                    : "Live org access is off, so only Setup, objects, Setup tabs and your bookmarks are searched. ") + verbs
            );
        }
        setFooterCount(results.length === 1 ? "1 result" : `${results.length} results`);
        // Order groups by best match (results are score-sorted, so a group's
        // first appearance marks its top score — a strong Setup match can thus
        // surface above the Objects group).
        const byGroup = {};
        const order = [];
        results.forEach((r) => {
            (byGroup[r.group] = byGroup[r.group] || []).push(r);
            if (!order.includes(r.group)) order.push(r.group);
        });
        order.forEach((g) => {
            const items = byGroup[g];
            if (!items.length) return;
            listEl.appendChild(groupHeader(g, items.length));
            renderRows(listEl, items);
        });
        setActive(0);
    }

    // The board's commands (COMMANDS in the data file) as keywords under their
    // group's name, with Shortcuts last. A keyword starts its command. Go to
    // comes before Setup so the short groups share the first line and Setup's
    // six commands get the second.
    function buildCmdBar() {
        const bar = document.createElement("div");
        bar.className = "cmd-bar";
        ["Objects", "Records", "Go to", "Setup"].forEach((name) => {
            const group = document.createElement("span");
            group.className = "cmd-group";
            const label = document.createElement("span");
            label.className = "cmd-label";
            label.textContent = name;
            group.appendChild(label);
            COMMANDS.filter((c) => c.group === name).forEach((c) => {
                const btn = document.createElement("button");
                btn.type = "button";
                btn.className = "cmd-verb";
                btn.textContent = c.verb;
                btn.title = c.text;
                btn.addEventListener("click", () => setVerb(c.verb, ""));
                group.appendChild(btn);
            });
            bar.appendChild(group);
        });
        const help = document.createElement("button");
        help.type = "button";
        help.className = "cmd-help";
        help.textContent = "Shortcuts";
        help.addEventListener("click", () => setShortcuts(true));
        bar.appendChild(help);
        return bar;
    }

    function setShortcuts(on) {
        shortcutsOpen = on;
        render(inputEl.value);
        focusInput();
    }

    // Shortcuts: every command with its short form, what it does and an
    // example; a name starts the command. Typing, Back or Esc returns to the board.
    function renderShortcuts() {
        panelEl.classList.add("board-mode");
        const el = (tag, cls, text) => {
            const n = document.createElement(tag);
            if (cls) n.className = cls;
            if (text !== undefined) n.textContent = text;
            return n;
        };
        const li = el("li", "help");
        const head = el("div", "help-head");
        const back = el("button", "help-back", "Back");
        back.type = "button";
        back.addEventListener("click", () => setShortcuts(false));
        head.append(el("span", "help-title", "Shortcuts"), back);
        li.append(
            head,
            el("p", "help-intro", "Type a command, or its short form, then what you're looking for. Shift+Enter opens a result in a background tab.")
        );
        COMMANDS.forEach((c) => {
            const row = el("div", "help-row");
            const name = el("button", "help-name", c.verb);
            name.type = "button";
            name.addEventListener("click", () => {
                shortcutsOpen = false;
                setVerb(c.verb, "");
            });
            row.append(name, el("span", "help-short", c.short || ""), el("span", "help-text", c.text), el("code", "", c.example));
            li.appendChild(row);
        });
        listEl.appendChild(li);
    }

    // No-search overview: two columns — left Recent+Records, right Bookmarks+Setup Tabs.
    function renderBoard() {
        panelEl.classList.add("board-mode");
        listEl.appendChild(buildCmdBar());
        // On a record or list, its object in Object Manager comes first, so
        // Alt+K, Enter opens it; → lists the object's other pages.
        const here = currentObject();
        if (here && !here.setup) {
            const url = `/lightning/setup/ObjectManager/${here.obj.api}/Details/view`;
            listEl.appendChild(groupHeader("This object"));
            renderRows(listEl, [
                {
                    label: `${here.obj.label || here.obj.api} in Object Manager`,
                    hint: "Setup",
                    group: GROUPS.OBJECT,
                    url,
                    actions: objectActions(here.obj.api).filter((a) => a.url !== url),
                },
            ]);
        }
        // On a record, the records it links to.
        boardSection(listEl, GROUPS.RELATED, hopItems().slice(0, 8));
        // Stored entries name their org (a string); a row's `org` is a saved
        // org, drawn as its color dot, so leave it out.
        const recent = recents.slice(0, 7).map(({ org, ...r }) => ({ ...r, group: GROUPS.RECENT }));
        const records = recentRecords.slice(0, recentCount);
        const bookmarks = staticCatalog.filter((i) => i.group === GROUPS.BOOKMARK).slice(0, 8);
        const setupTabs = staticCatalog.filter((i) => i.group === GROUPS.SETUP_TAB).slice(0, 8);

        const board = document.createElement("div");
        board.className = "board";
        const left = document.createElement("div");
        left.className = "column";
        const right = document.createElement("div");
        right.className = "column";

        // Fill left fully, then right, so ↑/↓ flat order reads column by column.
        boardSection(left, "Recent Setup", recent);
        boardSection(left, "Recently viewed", records);
        boardSection(right, GROUPS.BOOKMARK, bookmarks);
        boardSection(right, "Setup quick tabs", setupTabs);

        board.appendChild(left);
        board.appendChild(right);
        listEl.appendChild(board);
        if (flatResults.length) setActive(0);
    }

    function boardSection(col, name, items) {
        if (!items.length) return;
        col.appendChild(groupHeader(name));
        renderRows(col, items);
    }

    function toggleExpand(key) {
        expandedKey = expandedKey === key ? null : key;
        render(currentQuery);
        const pIdx = flatResults.findIndex((e) => !e.__action && e.url === key);
        if (pIdx < 0) return;
        setActive(expandedKey ? pIdx + 1 : pIdx);
    }

    function flashFooter(msg) {
        if (!footerEl) return;
        footerEl.textContent = msg;
        clearTimeout(footerResetTimer);
        footerResetTimer = setTimeout(resetFooter, 1800);
    }

    // Right-aligned footer text, e.g. "7 results" or "8 of 42 fields".
    function setFooterCount(text) {
        footerCount = text;
        const el = footerEl && footerEl.querySelector(".footer-count");
        if (el) el.textContent = text;
    }

    // Centered empty state: a title and an optional HTML body.
    function showEmpty(title, bodyHtml) {
        const e = document.createElement("li");
        e.className = "empty";
        e.innerHTML =
            UI_ICONS.searchLarge +
            '<span class="empty-title"></span>' +
            (bodyHtml ? `<span class="empty-body">${bodyHtml}</span>` : "");
        e.querySelector(".empty-title").textContent = title;
        listEl.appendChild(e);
    }

    function optionEls() {
        return listEl.querySelectorAll(".result:not(.disabled)");
    }

    function setActive(i) {
        const els = optionEls();
        if (!els.length) return;
        i = Math.max(0, Math.min(i, els.length - 1));
        els.forEach((el) => el.classList.remove("active"));
        activeIndex = i;
        const el = els[i];
        el.classList.add("active");
        el.scrollIntoView({ block: "nearest" });
        inputEl.setAttribute("aria-activedescendant", el.id);
        const entry = flatResults[i];
        if (entry && entry.loginUserId)
            setFooterCount(`You'll land on this same page as ${entry.label.split(" ")[0]}`);
        const rightKey = footerEl && footerEl.querySelector(".right-key");
        if (rightKey) rightKey.textContent = peekable(entry) ? "Preview" : "Actions";
        renderPeek();
    }

    // Shift+Enter: open `url` in a background tab and keep the palette open.
    function openInBackground(url) {
        const full = /^https?:\/\//.test(url) ? url : lightningOrigin() + url;
        try {
            chrome.runtime.sendMessage({ type: "openTab", url: full });
            flashFooter("Opened in a background tab");
        } catch (e) {
            /* context invalidated */
        }
    }

    function runAction(action, newTab, background) {
        if (!opened) return;
        if (action.kind === "nav" && background) {
            openInBackground(action.url);
        } else if (action.kind === "nav") {
            close();
            navigate(action.url, newTab || !!action.newTab);
        } else if (action.kind === "copy") {
            writeClipboard(action.text).then(
                () => flashFooter("Copied " + action.text),
                () => flashFooter("Copy failed")
            );
        } else if (action.kind === "loginAs") {
            setLoading("login", true);
            ask(
                "loginAs",
                {
                    userId: action.userId,
                    incognito: !!action.incognito,
                    // Land on the page we're currently viewing, as that user.
                    targetPath: location.pathname + location.search,
                },
                (resp) => {
                    setLoading("login", false);
                    if (resp && resp.ok) close();
                    else flashFooter((resp && resp.error) || "Login as failed");
                }
            );
        }
    }

    function choose(i, newTab, background) {
        if (!opened) return;
        const entry = flatResults[i];
        if (!entry) return;
        if (entry.__action) {
            runAction(entry.__action, newTab, background);
            return;
        }
        if (entry.loginUserId) {
            runAction({ kind: "loginAs", userId: entry.loginUserId, incognito: !!newTab });
            return;
        }
        if (entry.openLimits) {
            setVerb("limits", "");
            return;
        }
        // "count account" + Enter counts Accounts: the object row goes to the
        // count step. The count rows themselves do nothing.
        if (activeVerb === "count") {
            if (entry.objectApi) completeObject(entry);
            return;
        }
        pushRecent(entry);
        if (entry.group !== GROUPS.ACTION) recordPick(entry.url);
        if (background) return openInBackground(entry.url);
        close();
        navigate(entry.url, newTab || !!entry.newTab);
    }

    // On an object row, complete "<object> " to search its fields or list views,
    // or count it. The label is used when it names the object back, else the API name.
    function completeObject(entry) {
        const byLabel = fieldsTarget(entry.label + " ");
        inputEl.value = (byLabel && byLabel.obj.api === entry.objectApi ? entry.label : entry.objectApi) + " ";
        onInput();
        focusInput();
    }

    function onInputKeydown(e) {
        if (e.key === "Tab" && !activeVerb) {
            // Lock a verb typed without a trailing space (e.g. "new" + Tab).
            const first = inputEl.value.trim().toLowerCase().split(/\s+/)[0];
            const key = VERB_SHORT[first] || first;
            if (VERBS[key]) {
                e.preventDefault();
                setVerb(key, inputEl.value.trim().slice(first.length).trim());
            }
        } else if (e.key === "Tab" && (activeVerb === "fields" || activeVerb === "list" || activeVerb === "count")) {
            const entry = flatResults[activeIndex];
            if (entry && entry.objectApi) {
                e.preventDefault();
                completeObject(entry);
            }
        } else if (e.key === "Backspace" && activeVerb && inputEl.value === "") {
            // Backspace on an empty argument removes the verb chip.
            e.preventDefault();
            clearVerb();
        } else if (e.key === "ArrowDown") {
            e.preventDefault();
            setActive(activeIndex + 1);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setActive(activeIndex - 1);
        } else if (e.key === "ArrowRight") {
            const entry = flatResults[activeIndex];
            if (entry && !entry.__action && entry.actions && entry.actions.length) {
                e.preventDefault();
                if (expandedKey !== entry.url) toggleExpand(entry.url);
            } else if (peekable(entry) && !peekOpen) {
                e.preventDefault();
                setPeek(true);
            }
        } else if (e.key === "ArrowLeft") {
            if (expandedKey) {
                e.preventDefault();
                toggleExpand(expandedKey);
            } else if (peekOpen) {
                e.preventDefault();
                setPeek(false);
            }
        } else if (e.key === "Enter") {
            e.preventDefault();
            choose(activeIndex, e.metaKey || e.ctrlKey, e.shiftKey);
        }
        e.stopPropagation();
    }

    // select: also select the text (only on open, so refocusing never
    // selects what the user is typing).
    function focusInput(select) {
        if (inputEl) {
            inputEl.focus();
            if (select) inputEl.select();
        }
    }

    let lastSelection = ""; // page selection at the last open
    // fromKey: opened by the page key (see below), not the Chrome command.
    function open(fromKey) {
        if (!paletteEnabled) return;
        // Text selected on the page (a name, an Id) becomes the search, once:
        // a selection left behind doesn't fill every later open. Read before
        // the palette takes focus.
        const selected = String((window.getSelection && window.getSelection()) || "").replace(/\s+/g, " ").trim();
        const picked = selected !== lastSelection ? selected : "";
        lastSelection = selected;
        ensureOverlay();
        opened = true;
        overlayHost.classList.add("open");
        applyTheme();
        noticeEl.hidden = true;
        if (fromKey) checkShortcut();
        inputEl.value = "";
        inputEl.placeholder = DEFAULT_PLACEHOLDER;
        clearTimeout(searchTimer);
        runLiveSearch(""); // drop live results and any search in flight
        expandedKey = null;
        activeVerb = null;
        shortcutsOpen = false;
        autoVerbWord = null;
        inspectKey = null;
        inspectRecord = null;
        setPeek(false);
        // Previews are refetched per open, so a record edited since shows its new values.
        Object.keys(peekCache).forEach((id) => delete peekCache[id]);
        renderChip();
        resetFooter();
        render("");
        loadObjects();
        loadRecent();
        loadAdmin();
        loadApps();
        loadHop();
        fieldsFailed = {}; // retry objects whose fields failed to load
        // Refetched per open: the last viewed records change as you browse.
        listViewsCache = {};
        countCache = {};
        recentCache = {};
        if (!limitsLoading) limitsData = null;
        if (!activeUsersLoading) activeUsers = null;
        if (picked.length >= 2 && picked.length <= 80) {
            inputEl.value = picked;
            onInput();
        }
        // Robust focus: wait for paint, then re-assert on the next tick so we
        // win even if Lightning grabs focus back during the open animation.
        requestAnimationFrame(() =>
            requestAnimationFrame(() => {
                focusInput(true);
                setTimeout(() => focusInput(true), 60);
            })
        );
    }

    function close() {
        if (!opened) return;
        opened = false;
        overlayHost.classList.remove("open");
        clearTimeout(searchTimer);
        runLiveSearch("");
        inspectKey = null; // a late record response is then ignored
        fieldsKey = null; // likewise a late fields response
        listViewsKey = null;
        countKey = null;
        setLoading(null);
        // Don't leave the last results (record values, users) in the page.
        listEl.textContent = "";
        flatResults.length = 0;
        setPeek(false);
    }

    function toggle(fromKey) {
        opened ? close() : open(fromKey);
    }

    // The page key reaches the page when Chrome has no key for the palette,
    // which then only opens while the page has focus. Say so, with a button
    // to Chrome's shortcut page (only Chrome can set the key), unless
    // settings.shortcutNotice is off.
    const PALETTE_KEY = MOD === "⌘" ? "Option+K" : "Alt+K";
    function checkShortcut() {
        try {
            chrome.storage.sync.get(["settings"], (res) => {
                if (chrome.runtime.lastError || !res || !SFEN_SETTINGS.normalize(res.settings).shortcutNotice) return;
                chrome.runtime.sendMessage({ type: "paletteShortcut" }, (resp) => {
                    if (chrome.runtime.lastError || !resp || resp.shortcut || !opened) return;
                    showShortcutNotice();
                });
            });
        } catch (e) {
            /* context invalidated */
        }
    }

    function showShortcutNotice() {
        noticeEl.innerHTML =
            '<span class="notice-text"></span>' +
            '<button class="notice-btn primary" type="button">Set it</button>' +
            '<button class="notice-btn" type="button">Don’t show again</button>';
        noticeEl.querySelector(".notice-text").textContent =
            `${PALETTE_KEY} isn’t set as a Chrome shortcut. Set it so Navigator opens from anywhere on the page.`;
        const [setBtn, offBtn] = noticeEl.querySelectorAll(".notice-btn");
        setBtn.addEventListener("click", () => {
            noticeEl.hidden = true;
            close();
            try {
                chrome.runtime.sendMessage({ type: "paletteShortcut", open: true });
            } catch (e) {
                /* context invalidated */
            }
        });
        // Turns the setting off; Settings turns it back on.
        offBtn.addEventListener("click", () => {
            noticeEl.hidden = true;
            focusInput();
            try {
                chrome.storage.sync.get(["settings"], (res) => {
                    if (chrome.runtime.lastError || !res) return;
                    chrome.storage.sync.set({ settings: { ...(res.settings || {}), shortcutNotice: false } });
                });
            } catch (e) {
                /* context invalidated */
            }
        });
        noticeEl.hidden = false;
    }

    // ---- Init ------------------------------------------------------------
    buildStaticCatalog();
    loadOrg();
    try {
        SFEN_RECENTS.load(host, (list) => {
            recents = list;
        });
        chrome.storage.local.get({ [PICKS_KEY]: {} }, (res) => {
            if (!chrome.runtime.lastError && res) allPicks = res[PICKS_KEY] || {};
        });
        chrome.storage.sync.get(["settings"], (res) => {
            if (chrome.runtime.lastError || !res) return;
            if (res.settings && typeof res.settings.liveOrgAccess === "boolean") {
                liveEnabled = res.settings.liveOrgAccess;
            }
            if (res.settings && typeof res.settings.commandPalette === "boolean") {
                paletteEnabled = res.settings.commandPalette;
            }
            recentCount = SFEN_SETTINGS.normalize(res.settings).recentCount;
            showPackageApex = SFEN_SETTINGS.normalize(res.settings).showPackageApex;
        });
        chrome.storage.onChanged.addListener((changes, area) => {
            if (!extAlive()) return;
            if (area === "sync") {
                if (changes.sfTabs || changes.bookmarks)
                    buildStaticCatalog(() => opened && render(inputEl.value));
                if (changes.quickOrgs || changes.orgColors || changes.settings) loadOrg();
                if (changes.settings) {
                    const s = changes.settings.newValue || {};
                    if (typeof s.liveOrgAccess === "boolean") liveEnabled = s.liveOrgAccess;
                    recentCount = SFEN_SETTINGS.normalize(s).recentCount;
                    showPackageApex = SFEN_SETTINGS.normalize(s).showPackageApex;
                    if (!liveEnabled) {
                        // Drop everything fetched from the org right away; turning
                        // it back on fetches again.
                        liveObjects = null;
                        adminItems = [];
                        appItems = null;
                        fieldsCache = {};
                        fieldsKey = null;
                        setLoading("fields", false);
                        listViewsCache = {};
                        listRecentCache = {};
                        listViewsKey = null;
                        setLoading("listViews", false);
                        countCache = {};
                        countKey = null;
                        setLoading("count", false);
                        recentCache = {};
                        recentKey = null;
                        setLoading("recent", false);
                        limitsData = null;
                        activeUsers = null;
                        recentRecords = [];
                        catalogCache = null;
                        objectsRequested = false;
                        adminRequested = false;
                        adminLoaded = false;
                        adminFailed = false;
                        appsRequested = false;
                        hop = null;
                        hopKey = null;
                        Object.keys(peekCache).forEach((id) => delete peekCache[id]);
                        setPeek(false);
                        runLiveSearch("");
                        if (opened) render(inputEl.value);
                    }
                    if (typeof s.commandPalette === "boolean") paletteEnabled = s.commandPalette;
                    if (!paletteEnabled) close();
                    if (opened) applyTheme();
                }
            }
            if (area === "local" && changes.paletteRecents) {
                recents = SFEN_RECENTS.forOrg(changes.paletteRecents.newValue, host);
            }
            // Picks in other tabs, and Settings' Clear all data.
            if (area === "local" && changes[PICKS_KEY]) allPicks = changes[PICKS_KEY].newValue || {};
        });
    } catch (e) {
        /* context invalidated */
    }

    // ---- Setup visits ----------------------------------------------------
    // Recent Setup also keeps the Setup pages you reach without Navigator,
    // by clicking through Setup: landing on a page of the Setup list records
    // it under its name. Lightning changes pages without a reload, so the
    // address is checked every second.
    const SETUP_BY_PATH = new Map(SETUP_PAGES.map(([label, url]) => [url, label]));
    let lastPath = "";
    const visitTimer = setInterval(() => {
        if (!extAlive()) return clearInterval(visitTimer);
        const path = location.pathname;
        if (path === lastPath) return;
        lastPath = path;
        const label = SETUP_BY_PATH.get(path);
        if (label && !(recents[0] && recents[0].url === path)) pushRecent({ label, hint: "Setup", group: GROUPS.SETUP, url: path });
    }, 1000);

    // ---- Open via the Alt+K Chrome command ------------------------------
    // Alt+K is a browser command (see manifest), captured before the page and
    // relayed here by the background worker — so it works regardless of which
    // frame/element has focus, unlike a page keydown listener.
    try {
        chrome.runtime.onMessage.addListener((msg) => {
            if (msg && msg.type === "sfen-toggle-palette") toggleOnce();
        });
    } catch (e) {
        /* context invalidated */
    }

    // Some Chromium browsers, like Arc, don't deliver extension shortcuts
    // (issue #4), so Alt+K is also a page key, for when focus is in the page.
    // e.code, because Option+K on a Mac types "˚" as e.key. Real keys only,
    // so page scripts can't open the palette.
    document.addEventListener(
        "keydown",
        (e) => {
            if (!e.isTrusted) return;
            if (e.code !== "KeyK" || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || e.repeat) return;
            if (!paletteEnabled && !opened) return;
            e.preventDefault();
            e.stopPropagation();
            toggleOnce(true);
        },
        true
    );

    // A browser that sends both the command and the key would open and close
    // the palette at once: act on the first of the two.
    let lastToggle = 0;
    function toggleOnce(fromKey) {
        if (Date.now() - lastToggle < 300) return;
        lastToggle = Date.now();
        toggle(fromKey);
    }

    // Escape isn't a command, so it stays an in-page handler: collapse an open
    // ⋯ menu first, then the preview, then the Shortcuts list, then a verb
    // chip; only then close the palette.
    document.addEventListener(
        "keydown",
        (e) => {
            if (e.key === "Escape" && opened) {
                e.preventDefault();
                e.stopPropagation();
                if (expandedKey) toggleExpand(expandedKey);
                else if (peekOpen) setPeek(false);
                else if (shortcutsOpen) setShortcuts(false);
                else if (activeVerb) clearVerb();
                else close();
            }
        },
        true
    );
})();
